package sample;

import java.io.BufferedReader;
import java.io.PrintWriter;

/**
 * Created by chrism on 6/4/17.
 */
public class PrivateMessage
{
    static BufferedReader input;
    static PrintWriter output;

    static void display(BufferedReader in , PrintWriter out, String sender, String dest)
    {
        input = in;
        output = out;




    }


}
